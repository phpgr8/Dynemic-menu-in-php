<?php
$db_host = 'localhost';
$db_user = "gogab4tr_bfriendly_u";
$db_pass = "12345";
$db_name = "gogab4tr_bootstrapfriendly_demo";
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if ($conn) {
    //echo 'connected';
}
